/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.contacteditor;

import static contacteditor.ContactEditor.database_conn;
import static contacteditor.ContactEditor.mysql_driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Kisto
 */
public class report extends javax.swing.JFrame {
    private TableRowSorter sorter;
    private TableModel mdl;
    
    /**
     * Creates new form report
     */
    public report() {
        initComponents();
        addRow();
        with_courses.setSelected(true);
        mdl = (DefaultTableModel) rep_table.getModel();
        sorter = new TableRowSorter<>(mdl);
        rep_table.setRowSorter(sorter);
    }
    
    public void withoutcourses(){
    
             try{
            Class.forName(mysql_driver);
            Connection con = DriverManager.getConnection(database_conn[0],database_conn[1],database_conn[2]);
              int counting = 0; 
              
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `student_courses`");
            DefaultTableModel model = (DefaultTableModel) rep_table.getModel();
            while(rs.next()){counting++;}
//get students with courses            
            Statement stmt1 = con.createStatement();int []st_ids = new int[counting];
            int index = 0;
            ResultSet rs1 = stmt1.executeQuery("SELECT * FROM `student_courses`");
            while(rs1.next()){st_ids[index] = rs1.getInt("student_id");index++;}

//get students without courses
            Statement stmt2 = con.createStatement();
            ResultSet rs2 = stmt2.executeQuery("SELECT * FROM `students`");
            while(rs2.next()){
                
               boolean loc = false;
                int std_id2 = rs2.getInt("id");
                
                for(int k=0;k<st_ids.length;k++){
                    System.out.print("\n student_id = "+std_id2+" => stundent= "+st_ids[k]);
                   if(std_id2==st_ids[k]){
                              loc = true;
                   }
                }
                if(!loc){
                 Object []row = {rs2.getString("student_number"),rs2.getString("firstname"),rs2.getString("middlename"),rs2.getString("lastname"),null,null,0,0};
                  model.addRow(row);
                }
         
            }
            
            
            
            
        }catch(Exception e){System.out.print(e);}
    
    
    }

    public void withoutstudents(){
    
             try{
            Class.forName(mysql_driver);
            Connection con = DriverManager.getConnection(database_conn[0],database_conn[1],database_conn[2]);
              int counting = 0; 
              
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `student_courses`");
            DefaultTableModel model = (DefaultTableModel) rep_table.getModel();
            while(rs.next()){counting++;}
//get students with courses            
            Statement stmt1 = con.createStatement();int []cs_ids = new int[counting];
            int index = 0;
            ResultSet rs1 = stmt1.executeQuery("SELECT * FROM `student_courses`");
            while(rs1.next()){cs_ids[index] = rs1.getInt("course_id");index++;}

//get students without courses
            Statement stmt2 = con.createStatement();
            ResultSet rs2 = stmt2.executeQuery("SELECT * FROM `courses`");
            while(rs2.next()){
                
               boolean loc = false;
                int cs_id2 = rs2.getInt("id");
                
                for(int k=0;k<cs_ids.length;k++){
                   if(cs_id2==cs_ids[k]){
                              loc = true;
                   }
                }
                if(!loc){
                 Object []row = {null,null,null,null,rs2.getString("course_code"),rs2.getString("course_description"),0,0};
                  model.addRow(row);
                }
         
            }
            
            
            
            
        }catch(Exception e){System.out.print(e);}
    
    
    }
    
    
    
    
    public void addRow(){
    
             try{
            Class.forName(mysql_driver);
            Connection con = DriverManager.getConnection(database_conn[0],database_conn[1],database_conn[2]);
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM `student_courses`");
            
            
             DefaultTableModel model = (DefaultTableModel) rep_table.getModel();
            
            while(rs.next()){
                
            int stud_id     = rs.getInt("student_id");
            int course_id  = rs.getInt("course_id");
            
            System.out.print("the student id = "+stud_id);
            
                Object []row = {null,null,null,null,null,null,rs.getInt("course_id"),rs.getInt("student_id")};
                model.addRow(row);
            }
            
           
            Statement stmt1 = con.createStatement();
           
             
            for(int i=0;i<rep_table.getRowCount();i++){
                int stid = (int) rep_table.getValueAt(i,7);
                String st1 = "SELECT * FROM `students` WHERE `id`="+stid+"";
                 ResultSet rs1 = stmt1.executeQuery(st1);
           while(rs1.next()){
                model.setValueAt(rs1.getString("student_number"),i,0);
                model.setValueAt(rs1.getString("firstname"),i,1);
                model.setValueAt(rs1.getString("middlename"),i,2);
                model.setValueAt(rs1.getString("lastname"),i,3);
               }
            
            }
            
            
            Statement stmt2 = con.createStatement();
           
             
            for(int i=0;i<rep_table.getRowCount();i++){
                int cid = (int) rep_table.getValueAt(i,6);
                String st2 = "SELECT * FROM `courses` WHERE `id`="+cid+"";
                 ResultSet rs2 = stmt2.executeQuery(st2);
           while(rs2.next()){
                model.setValueAt(rs2.getString("course_code"),i,4);
                model.setValueAt(rs2.getString("course_description"),i,5);
               }
            
            }
            
            
        }catch(Exception e){System.out.print(e);}
    }
    
    
    
  public void search(String str){
    if(str.length()==0){
    sorter.setRowFilter(null);
    }else{
    sorter.setRowFilter(RowFilter.regexFilter("(?i)"+str));
   
            }
        
        }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        rep_table = new javax.swing.JTable();
        search_field = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        without_courses = new javax.swing.JRadioButton();
        without_students = new javax.swing.JRadioButton();
        with_courses = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 72)); // NOI18N
        jLabel1.setText("                     REPORT");

        rep_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "STUDENT NUMBER", "FIRSTNAME", "MIDDLENAME", "LASTNAME", "COURSE CODE", "COURSE DESCRIPTION", "", ""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(rep_table);
        if (rep_table.getColumnModel().getColumnCount() > 0) {
            rep_table.getColumnModel().getColumn(6).setMinWidth(0);
            rep_table.getColumnModel().getColumn(6).setPreferredWidth(0);
            rep_table.getColumnModel().getColumn(6).setMaxWidth(0);
            rep_table.getColumnModel().getColumn(7).setMinWidth(0);
            rep_table.getColumnModel().getColumn(7).setPreferredWidth(0);
            rep_table.getColumnModel().getColumn(7).setMaxWidth(0);
        }

        search_field.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        search_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_fieldActionPerformed(evt);
            }
        });
        search_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                search_fieldKeyTyped(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel2.setText("SEARCH");

        jButton1.setText("<< MENU");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        without_courses.setText("STUDENTS WITHOUT COURSES");
        without_courses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                without_coursesActionPerformed(evt);
            }
        });

        without_students.setText("COURSES WITHOUT STUDENTS");
        without_students.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                without_studentsActionPerformed(evt);
            }
        });

        with_courses.setText("STUDENTS WITH COURSES");
        with_courses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                with_coursesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(search_field, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(with_courses)
                .addGap(26, 26, 26)
                .addComponent(without_courses)
                .addGap(65, 65, 65)
                .addComponent(without_students)
                .addGap(21, 21, 21))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(without_courses)
                    .addComponent(without_students)
                    .addComponent(with_courses))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(search_field)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void search_fieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_fieldKeyTyped
        // TODO add your handling code here:
       search(search_field.getText());
    }//GEN-LAST:event_search_fieldKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu().setVisible(true);
            }
        });
    }//GEN-LAST:event_jButton1ActionPerformed

    private void with_coursesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_with_coursesActionPerformed
        // TODO add your handling code here:
        
       without_courses.setSelected(false);
       without_students.setSelected(false);
      DefaultTableModel model = (DefaultTableModel) rep_table.getModel();
      model.setRowCount(0);
      addRow();
    
    }//GEN-LAST:event_with_coursesActionPerformed

    private void search_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_fieldActionPerformed

    private void without_coursesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_without_coursesActionPerformed
        // TODO add your handling code here:
       
       with_courses.setSelected(false);
       without_students.setSelected(false);
       DefaultTableModel model = (DefaultTableModel) rep_table.getModel();
       model.setRowCount(0);
        withoutcourses();
    }//GEN-LAST:event_without_coursesActionPerformed

    private void without_studentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_without_studentsActionPerformed
        // TODO add your handling code here:
       without_courses.setSelected(false);
       with_courses.setSelected(false);
       DefaultTableModel model = (DefaultTableModel) rep_table.getModel();
       model.setRowCount(0);
       withoutstudents();
    }//GEN-LAST:event_without_studentsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new report().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable rep_table;
    private javax.swing.JTextField search_field;
    private javax.swing.JRadioButton with_courses;
    private javax.swing.JRadioButton without_courses;
    private javax.swing.JRadioButton without_students;
    // End of variables declaration//GEN-END:variables
}
