/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contacteditor;
import java.sql.*;
import javax.swing.JOptionPane;
import my.contacteditor.Login;


/**
 *
 * @author Kisto
 */
public class ContactEditor {
    public static String mysql_driver  = "com.mysql.jdbc.Driver";
    public static String []database_conn = {"jdbc:mysql://localhost:3306/srs","root",""};
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       /*      java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new test().setVisible(true);
               
            }
        });*/
        /*
        try{
            Class.forName(mysql_driver);
            Connection con = DriverManager.getConnection(database_conn[0],database_conn[1],database_conn[2]);
            
            Statement stmt = con.createStatement();
            int rs = stmt.executeUpdate("INSERT INTO `admin` (`username`,`password`) VALUES ('admin2','admin4') ");
            
            
            
        }catch(Exception e){System.out.print(e);}*/
        
    }
    
}
