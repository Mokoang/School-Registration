School registration system

The code uses java and mysql database
database details can be found in the contactEditor.java file

They are as follows :
    public static String mysql_driver  = "com.mysql.jdbc.Driver";
    public static String []database_conn = {"jdbc:mysql://localhost:3306/srs","root",""};

You can change them to lfit ur databse


The main running file is index.java


Admin login details: username=admin
                     passwrod=admin


Student login details: username=kisto
                       password=1234


Databse can be foud in a text file in  a folder name: database

there are pictures of project running in folder name : project runnung pics


