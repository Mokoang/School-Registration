-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2021 at 11:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `srs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(10, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `record_date` date NOT NULL DEFAULT curdate(),
  `course_code` varchar(255) NOT NULL,
  `course_description` varchar(255) DEFAULT NULL,
  `registered_students` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `record_date`, `course_code`, `course_description`, `registered_students`) VALUES
(7, '2021-07-21', 'E330', 'ENGLISH LITERATURE', 1),
(8, '2021-07-22', 'B1230', 'BIOLOGY', 0),
(9, '2021-07-22', 'A123', 'ART', 1),
(10, '2021-07-22', 'H123', 'HISTORY', 1),
(11, '2021-07-22', 'M123', 'MATHEMATICS', 1),
(12, '2021-07-22', 'G123', 'GEOGRAPHY', 1),
(13, '2021-07-22', 'C123', 'CHEMISTRY', 0),
(14, '2021-07-22', 'CR12', 'CRAPHIC DESIGN', 0),
(15, '2021-07-22', 'P123', 'PHYSICS', 0),
(16, '2021-07-22', 'PHY562', 'PHYSICAL SCIENCE', 0),
(17, '2021-07-22', 'CS2100', 'COMPUTER SCIENCE', 0),
(18, '2021-07-22', 'CS3400', 'COMPUTER OPERTING SYSTEMS', 0),
(19, '2021-07-22', 'CS2300', 'COMPUTER NETWORKING', 0);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_number` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) NOT NULL,
  `gender` varchar(1) NOT NULL DEFAULT 'M',
  `grade` varchar(255) NOT NULL DEFAULT 'Grade_A',
  `record_date` date NOT NULL DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_number`, `firstname`, `middlename`, `lastname`, `gender`, `grade`, `record_date`) VALUES
(1, 201001623, 'Mokoang', 'Estras', 'Nkoe', 'M', '4', '2021-07-22'),
(2, 201001789, 'Kenedy', '', 'Silvester', 'F', '5', '2021-07-22'),
(3, 201007565, 'Maya', '', 'Scofield', 'F', '5', '2021-07-22'),
(4, 201093333, 'Anton', '', 'Scofield', 'M', '7', '2021-07-22'),
(5, 201001643, 'Reitumetse', 'Priscilla ', 'Mojaki', 'F', '7', '2021-07-22'),
(6, 201001788, 'Manthapo', 'Layla', 'Nkoe', 'F', '4', '2021-07-22'),
(7, 201001777, 'Nthina', 'Augostine', 'Nkoe', 'M', '5', '2021-07-22'),
(8, 201000001, 'Katsane', '', 'Katsane', 'M', '5', '2021-07-22'),
(10, 201000003, 'Rating', 'Maenba', 'Rating', 'M', '5', '2021-07-22'),
(11, 201009877, 'Maime', '', 'Mofo', 'M', '5', '2021-07-23'),
(12, 201002973, 'Malibe', '', 'Alvios', 'M', '7', '2021-07-23'),
(13, 201001928, 'Manlla', '', 'meiki', 'M', '9', '2021-07-23'),
(14, 2010191, 'Malla', '', 'Mullo', 'M', '11', '2021-07-23'),
(15, 201928383, 'Man', '', 'Man2', 'M', '9', '2021-07-23'),
(16, 20104455, 'mike', '', 'meike', 'M', '5', '2021-07-23'),
(17, 201929222, 'man', '', 'mull', 'M', '5', '2021-07-23'),
(18, 20933444, 'Makaile', '', 'Mullow', 'M', '5', '2021-07-23'),
(19, 45567677, 'mailioo', '', 'kolfi', 'M', '8', '2021-07-23');

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE `student_courses` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`id`, `student_id`, `course_id`) VALUES
(82, 13, 7),
(83, 13, 9),
(84, 13, 10),
(85, 13, 11),
(86, 13, 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `student_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `student_number`) VALUES
(1, 'kisto', '1234', 201001928),
(3, 'katiso', '1234', 201928383),
(4, 'meik', '1234', 201929222),
(7, 'baba', '12345', 20933444),
(8, 'mull', '987', 45567677);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `student_courses`
--
ALTER TABLE `student_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
